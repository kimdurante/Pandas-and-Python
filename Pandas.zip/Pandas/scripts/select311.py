import pandas as pd

cases = pd.read_csv("./../data/311_Cases2019.csv", index_col="CaseID")
cases = cases.loc[:, "Opened":"Source"]
print(cases.head())