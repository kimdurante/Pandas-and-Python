import pandas as pd

cases = pd.read_csv("./../data/311_Cases2019.csv", index_col="CaseID")
cases = cases.loc[:, "Opened":"Source"]
cat_counts = cases["Category"].value_counts()[:5]
nhood_counts = cases["Neighborhood"].value_counts()[:5]
print (cat_counts)